```
config:
    if mkdocs.toml load from there
    if README.md load default
```

### Default config

```toml
[mkdocs]
nav = [
    {title: 'Home', path: 'README.md'}
]
loaders = [
    {type: 'dir', dir: '.'},
    {type: 'package', package: 'mkdocs.theme'}
]
resources = {
    pages: {patterns: ['*.md']},
    statics: {patterns: ['*.js', '*.css', '*.svg', '*.png', '*.jpg']},
    templates: {dir: 'templates', default: 'base.html'}
}
commands = {
    serve: {port: 8080},
    build: {dir: 'site'}
}
```

* 'path to url' -> ...
* 'markdown' -> ...
* '' -> ...

### Full project

```toml
[mkdocs]
nav = [
    {title: "...", path: "index.md"}
]
loaders = [
    docs: {type: 'dir', dir: 'docs'},
    theme: {type: 'package', package: 'mkdocs.theme'}
]
handlers = {
    pages: {patterns: ["*.md"]},
    statics: {patterns: ["*"]},
    templates: {dir: "templates/", default: "base.html", filters: ...}
}
commands = {
    serve: {port: 8080},
    build: {dir: "site"},
}
```

### Context


page.url
page.html
page.text
page.toc

page.next
page.previous

site.nav
site.pages
site.statics
site.templates

config

---

# Pages
# --------------------------------------------
# index.md           index.html
# configuration.md   configuration/index.html
# navigation.md      navigation/index.html
# styling.md         styling/index.html
# writing.md         writing/index.html
#
# Statics
# --------------------------------------------
# css/highlightjs-copy.min.css
# css/highlightjs.min.css
# css/theme.css
# img/codercat.png
# js/highlightjs-copy.min.js
# js/highlightjs.min.js
# js/theme.js
#
# Templates
# ---------------------------------------------
# templates/base.html


# $ mkdocs check
# Configuration
# ============================================
# mkdocs.toml
#
# Navigation
# =============================================
# Home                     /
# Topics > Configuration   /configuration/
# Topics > Navigation      /navigation/
# Topics > Styling         /styling/
# Topics > Writing         /writing/
#
# Loaders
# ============================================
# Directory   docs/
# Package     mkdocs.theme
#
# Resources
# ============================================
# Pages
# --------------------------------------------
# index.md           /
# configuration.md   /configuration/
# navigation.md      /navigation/
# styling.md         /styling/
# writing.md         /writing/
#
# Statics
# --------------------------------------------
# css/highlightjs-copy.min.css
# css/highlightjs.min.css
# css/theme.css
# img/codercat.png
# js/highlightjs-copy.min.js
# js/highlightjs.min.js
# js/theme.js
#
# Templates
# ---------------------------------------------
# templates/base.html
