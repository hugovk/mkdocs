__title__ = "mkdocs"
__version__ = "2.0"
