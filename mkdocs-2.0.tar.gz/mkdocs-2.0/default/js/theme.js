hljs.addPlugin(new CopyButtonPlugin({autohide: false}));
hljs.highlightAll();