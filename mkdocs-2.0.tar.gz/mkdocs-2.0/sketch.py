import contextvars
import posixpath


url_ctx = contextvars.ContextVar('url_ctx')


class URLCtx:
    def __init__(self, where: str):
        self.where = where

    def __enter__(self):
        self._token = url_ctx.set(self.where)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        url_ctx.reset(self._token)


def url(url_to):
    url_from = url_ctx.get('/')
    return posixpath.relpath(url_to, url_from)


# ...

print(url('/css/base.css'))

with URLCtx('/'):
    print(url('/css/base.css'))
with URLCtx('/configuration'):
    print(url('/css/base.css'))
with URLCtx('/configuration/'):
    print(url('/css/base.css'))
