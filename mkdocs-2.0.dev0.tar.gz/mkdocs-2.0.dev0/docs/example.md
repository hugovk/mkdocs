# README.md

A short `README.md` to copy & paste as a getting started template.

````markdown
# MkDocs

MkDocs is a smart, simple, website design tool.

## Installation

Install the `mkdocs` command line tool...

```
$ pip install https://www.encode.io/mkdocs/mkdocs-2.0.dev0.tar.gz
```

*This will install the version 2.0 pre-release.*

## Getting started

1. Create a `README.md` page.
2. Run `mkdocs serve` to view your documentation in a browser.
3. Run `mkdocs build` to build a static website ready to host.

*MkDocs supports GitHub Flavored Markdown for page authoring.*
````
