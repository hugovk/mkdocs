import mkdocs


if __name__ == '__main__':
    mkdocs.cli()
